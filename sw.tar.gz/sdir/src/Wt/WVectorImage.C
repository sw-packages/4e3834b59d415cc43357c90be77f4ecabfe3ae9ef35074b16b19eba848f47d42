/*
 * Copyright (C) 2008 Emweb bvba, Kessel-Lo, Belgium.
 *
 * See the LICENSE file for terms of use.
 */

#include "Wt/WVectorImage.h"

namespace Wt {

WVectorImage::~WVectorImage()
{ }

}
